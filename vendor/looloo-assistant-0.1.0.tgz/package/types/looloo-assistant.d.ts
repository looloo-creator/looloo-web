import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';

type ChatMessageRole = 'assistant' | 'user';
interface ChatMessage {
    id: string;
    role: ChatMessageRole;
    content: string;
    /** Optional time label, for example "10:42 AM". */
    time?: string;
    /** Optional assistant attribution shown below a response. */
    author?: string;
}

/** A saved conversation entry displayed in the chat history sidebar. */
interface ChatConversation {
    id: string;
    title: string;
    /** Optional human-readable date or time label. */
    updatedAt?: string;
}

interface ChatSuggestion {
    title: string;
    prompt: string;
    /** Optional short explanation shown on the suggestion card. */
    description?: string;
    icon?: 'sparkles' | 'search' | 'lightbulb' | 'chart';
}

declare class ChatWindowComponent {
    title: string;
    subtitle: string;
    messages: ChatMessage[];
    conversationHistory: ChatConversation[];
    activeConversationId: string | null;
    suggestions: ChatSuggestion[];
    placeholder: string;
    disabled: boolean;
    showSidebar: boolean;
    welcomeTitle: string;
    welcomeDescription: string;
    readonly sendMessage: EventEmitter<string>;
    readonly suggestionSelected: EventEmitter<ChatSuggestion>;
    readonly newConversation: EventEmitter<void>;
    readonly conversationSelected: EventEmitter<ChatConversation>;
    draft: string;
    submit(): void;
    chooseSuggestion(suggestion: ChatSuggestion): void;
    startNewConversation(): void;
    selectConversation(conversation: ChatConversation): void;
    trackMessage(_index: number, message: ChatMessage): string;
    trackConversation(_index: number, conversation: ChatConversation): string;
    trackSuggestion(_index: number, suggestion: ChatSuggestion): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatWindowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatWindowComponent, "looloo-assistant-chat", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "messages": { "alias": "messages"; "required": false; }; "conversationHistory": { "alias": "conversationHistory"; "required": false; }; "activeConversationId": { "alias": "activeConversationId"; "required": false; }; "suggestions": { "alias": "suggestions"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "showSidebar": { "alias": "showSidebar"; "required": false; }; "welcomeTitle": { "alias": "welcomeTitle"; "required": false; }; "welcomeDescription": { "alias": "welcomeDescription"; "required": false; }; }, { "sendMessage": "sendMessage"; "suggestionSelected": "suggestionSelected"; "newConversation": "newConversation"; "conversationSelected": "conversationSelected"; }, never, never, true, never>;
}

export { ChatWindowComponent };
export type { ChatConversation, ChatMessage, ChatMessageRole, ChatSuggestion };
